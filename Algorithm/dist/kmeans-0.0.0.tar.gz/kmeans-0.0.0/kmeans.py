import pandas as pd
from kmeans import algo
import mysql.connector


dbconfig = {'host': '127.0.0.1',
            'database': 'kmeans',
            'user': 'root',
            'password': '7787',
            }
conn = mysql.connector.connect(**dbconfig)
cursor = conn.cursor()

data = pd.read_csv('data2.csv')
X = data.to_numpy()
final_clusters = final_algo.find_clusters(X)

cluster = final_algo.elbow_method(X, final_clusters)

k = final_clusters[cluster]

cursor.execute("""truncate table users""")
conn.commit()
v = 0
for c in k:
    v = v+1
    cursor.execute("""insert into users 
            (id, cluster)
            values
            (%s, %s)""", (v, k[c]))
    conn.commit()
cursor.close()
conn.close()




