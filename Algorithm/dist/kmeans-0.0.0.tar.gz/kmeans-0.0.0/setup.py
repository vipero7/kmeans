from setuptools import setup

setup(
    name='kmeans',
    py_modules=['kmeans'],
)
